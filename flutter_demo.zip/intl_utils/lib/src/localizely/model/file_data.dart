import 'dart:typed_data';

class FileData {
  String name;
  Uint8List bytes;

  FileData(this.name, this.bytes);
}
