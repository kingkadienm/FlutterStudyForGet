import 'package:language_helper/image_path_generator.dart';
import 'package:language_helper/language_helper.dart';
import 'package:source_gen/source_gen.dart';
import 'package:build/build.dart';

Builder imagePathBuilder(BuilderOptions options) =>
    LibraryBuilder(LanguageHelper());