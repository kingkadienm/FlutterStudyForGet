import 'dart:math';
import 'dart:mirrors';

import 'package:analyzer/dart/element/element.dart';
import 'package:build/src/builder/build_step.dart';
import 'package:source_gen/source_gen.dart';

import 'language_config.dart';

class LanguageHelper extends GeneratorForAnnotation<LanguageConfig> {
  @override
  generateForAnnotatedElement(
      Element element, ConstantReader annotation, BuildStep buildStep) {
    // //AppLanguageKey
    // print(element.name);
    // //AppLanguageKey
    // print(element.displayName);
    // //abstract class AppLanguageKey
    // print(element.toString());
    // //flutter_demo/lib/language/language_key.dart
    // print(element.enclosingElement);
    // //CLASS
    // print(element.kind);
    // //[@LanguageConfig LanguageConfig(String languageKey, String source)]
    // print(element.metadata);

    print('开始解析');
    //  final dynamic languageKey;
    //   final dynamic languageZh;
    var languageKey = annotation.read('languageKey') ;

    print('key : ${languageKey.objectValue.type}');

    var dartType = languageKey.objectValue.type;


    var element2 = dartType?.element;

    print(element2?.toString());

    // MirrorSystem.getName(nameValue.simpleName);

    // print('toString : ${languageKey.toString()}');

    // print('--------------------------------');
    // var languageZh = annotation.read('languageZh');
    // print('languageZh : ${languageZh.runtimeType}');
    // print('symbolValue : ${languageZh.isSymbol}');
    // print('toString : ${languageZh.toString()}');
    //
    // ClassMirror mirror = reflectClass(languageKey.objectValue.runtimeType);
    // var declarations = mirror.declarations;
    // var values = declarations.values;
    // for (var value in values) {
    //   print('------:$value');
    // }
  }
}
