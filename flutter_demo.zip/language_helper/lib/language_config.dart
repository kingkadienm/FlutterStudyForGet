/// @class : language_config
/// @date : 2023-01-06 14:57
/// @name : wangzs
/// @description : 
class LanguageConfig{
  final Object languageKey;
  final Object languageZh;

  const LanguageConfig(this.languageKey, this.languageZh);
}